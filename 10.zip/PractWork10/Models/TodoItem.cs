﻿namespace PractWork10.Models
{
    /// <summary>
    /// Статус выполнения задачи
    /// </summary>
    public enum Status
    {
        /// <summary>
        /// Ожидает выполнения
        /// </summary>
        Pending,

        /// <summary>
        /// В процессе выполнения
        /// </summary>
        InProgress,

        /// <summary>
        /// Завершена
        /// </summary>
        Completed
    }

    /// <summary>
    /// Модель задачи (ToDo)
    /// </summary>
    public class TodoItem
    {
        /// <summary>
        /// Уникальный идентификатор задачи
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Название задачи
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Подробное описание задачи
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Срок выполнения задачи
        /// </summary>
        public DateTime DueDate { get; set; }

        /// <summary>
        /// Текущий статус задачи
        /// </summary>
        public Status Status { get; set; }
    }
}
