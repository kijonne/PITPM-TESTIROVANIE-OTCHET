﻿using Microsoft.AspNetCore.Mvc;
using PractWork10.Models;

namespace PractWork10.Controllers
{
    /// <summary>
    /// Контроллер для управления задачами
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]

    public class TodoContoller : Controller
    {
        private static List<TodoItem> _todos = new();
        private static int _nextId = 1;

        /// <summary>
        /// Получить все задачи
        /// </summary>
        /// <returns>Список всех задач</returns>
        /// <response code="200">Успешно возвращен список задач</response>
        [HttpGet]
        [ProducesResponseType(typeof(List<TodoItem>), StatusCodes.Status200OK)]
        public IActionResult GetAll()
        {
            return Ok(_todos);
        }

        /// <summary>
        /// Получить задачу по ID
        /// </summary>
        /// <param name="id">Идентификатор задачи</param>
        /// <returns>Задача с указанным ID</returns>
        /// <remarks>
        /// Пример запроса:
        /// 
        /// GET /api/todo/1
        /// </remarks>
        /// <response code="200">Задача найдена</response>
        /// <response code="404">Задача с указанным ID не найдена</response>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(TodoItem), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public IActionResult GetById(int id)
        {
            var todo = _todos.FirstOrDefault(t => t.Id == id);
            if (todo == null)
                return NotFound($"Задача с ID {id} не найдена");

            return Ok(todo);
        }

        /// <summary>
        /// Создать новую задачу
        /// </summary>
        /// <param name="item">Данные новой задачи</param>
        /// <returns>Созданная задача</returns>
        /// <remarks>
        /// Пример запроса:
        /// 
        /// POST /api/todo
        /// {
        ///     "id": 0, // Игнорируется, генерируется автоматически
        ///     "name": "Сделать практическую работу",
        ///     "description": "Выполнить все задания по документированию",
        ///     "dueDate": "2024-12-31T23:59:59",
        ///     "status": 0
        /// }
        /// </remarks>
        /// <response code="201">Задача успешно создана</response>
        /// <response code="400">Некорректные данные</response>
        [HttpPost]
        [ProducesResponseType(typeof(TodoItem), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public IActionResult Create([FromBody] TodoItem item)
        {
            if (item == null)
                return BadRequest("Данные задачи не могут быть пустыми");

            if (string.IsNullOrWhiteSpace(item.Name))
                return BadRequest("Название задачи обязательно");

            item.Id = _nextId++;
            _todos.Add(item);

            return CreatedAtAction(nameof(GetById), new { id = item.Id }, item);
        }


        /// <summary>
        /// Обновить существующую задачу
        /// </summary>
        /// <param name="id">Идентификатор обновляемой задачи</param>
        /// <param name="item">Новые данные задачи</param>
        /// <returns>Обновленная задача</returns>
        /// <remarks>
        /// Пример запроса:
        /// 
        /// PUT /api/todo/1
        /// {
        ///     "id": 1,
        ///     "name": "Обновленное название",
        ///     "description": "Обновленное описание",
        ///     "dueDate": "2024-12-25T12:00:00",
        ///     "status": 1
        /// }
        /// </remarks>
        /// <response code="200">Задача успешно обновлена</response>
        /// <response code="400">Неверные данные</response>
        /// <response code="404">Задача не найдена</response>
        [HttpPut("{id}")]
        [ProducesResponseType(typeof(TodoItem), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public IActionResult Update(int id, [FromBody] TodoItem item)
        {
            if (item == null || item.Id != id)
                return BadRequest("Неверные данные");

            var existing = _todos.FirstOrDefault(t => t.Id == id);
            if (existing == null)
                return NotFound($"Задача с ID {id} не найдена");

            existing.Name = item.Name;
            existing.Description = item.Description;
            existing.DueDate = item.DueDate;
            existing.Status = item.Status;

            return Ok(existing);
        }

        /// <summary>
        /// Удалить задачу
        /// </summary>
        /// <param name="id">Идентификатор удаляемой задачи</param>
        /// <returns>Результат операции</returns>
        /// <remarks>
        /// Пример запроса:
        /// 
        /// DELETE /api/todo/1
        /// </remarks>
        /// <response code="204">Задача успешно удалена</response>
        /// <response code="404">Задача не найдена</response>
        [HttpDelete("{id}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public IActionResult Delete(int id)
        {
            var todo = _todos.FirstOrDefault(t => t.Id == id);
            if (todo == null)
                return NotFound($"Задача с ID {id} не найдена");

            _todos.Remove(todo);
            return NoContent();
        }
    }
}

